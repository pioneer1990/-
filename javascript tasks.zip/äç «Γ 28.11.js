/* 1. Дан инпут. Ведите в него что нибудь. Сохраните значение в куки.*/
let name = "Сережа крутой чувак";
let age = "Ему 31 годик";
document.cookie = encodeURIComponent(name) + '=' + encodeURIComponent(age);
alert(document.cookie);

/* 2. Дана форма с инпутами. Пользователь вводит какие-то данные и закрывает 
страницу (не факт, что он заполнил всю форму). Сделайте так, чтобы при следующем 
заходе на страницу введенные им ранее данные стояли на своих местах.*/
<input type="text" id="one">
<input type="text" id="two">
<input type="text" id="three"> 

function getCookie(cname) {
var name = cname + "=";
	var decodedCookie = decodeURIComponent(document.cookie);
var ca = decodedCookie.split(';');
	for (var i = 0; i < ca.length; i++) {
var c = ca[i];
	while (c.charAt(0) == ' ') {
c = c.substring(1);
	}
if (c.indexOf(name) == 0) {
	return c.substring(name.length, c.length);
	}
}
return '';
}

$(document).ready(function () {
	var one = getCookie("one"); if (one) $('#one').val(one);
	var two = getCookie("two"); if (two) $('#two').val(two);
	var three = getCookie("three"); if (three) $('#three').val(three);

	$(window).on('beforeunload', function () {
		$('input').each(function () {
			document.cookie = $(this).attr('id') + "=" + $(this).val();
		});
  	})
);             

/* 3. Даны чекбоксы. Пользователь произвольно отмечает их и закрывает страницу.  
Сделайте так, чтобы при следующем заходе на страницу чекбоксы стали отмеченными
так, как это сделал пользователь ранее.*/

<input type="checkbox" id="zero">
<input type="checkbox" id="one">
<input type="checkbox" id="two"> 
function getCookie(cname) {
	var name = cname + "=";
	var decodedCookie = decodeURIComponent(document.cookie);
	var ca = decodedCookie.split(';');
	for (var i = 0; i < ca.length; i++) {
		var c = ca[i];
		while (c.charAt(0) == ' ') {
			c = c.substring(1);
		}
		if (c.indexOf(name) == 0) {
			return c.substring(name.length, c.length);
		}
	}
	return '';
}

$(document).ready(function () {
	var one = getCookie("zero"); if (one == "true") $('#zero').prop('checked', true); 
	var two = getCookie("one"); if (two == "true") $('#one').prop('checked', true); 
	var three = getCookie("two"); if (three == "true") $('#two').prop('checked', true); 

	$(window).on('beforeunload', function () {
		$('input').each(function () {
			document.cookie = $(this).attr('id') + "=" + $(this).is(':checked');
		});
  	})
});            


 const form1 = document.getElementById("form");
 function saveForm(t) {
	setDataForm(t)
 }

 function setDataForm(tag) {
	for (let i = 0; i < tag.length; i++) {
 		const tagElement = tag[i];
 		console.log(tagElement);
 		if (tagElement.type === 'checkbox' || tagElement.type ==='radio')
 			tagElement.checked
 				? tagElement.value = true
 				: tagElement.value = false
 		localStorage.setItem(tagElement.id, tagElement.value);
 	}
 }

 function getDataForm(tag) {
 	for (let i = 0; i < localStorage.length; i++) {
 		if (localStorage.hasOwnProperty(tag.children[i].id)){
 			tag.children[i].value = LocalStorage.getitem(tag.children[i].id)
 			if (tag.children[i].value === 'true'){
 				tag.children[i].setAttribute('checked','checked');
 			}
 		}
 	}
 

 /* 4. Дан textArea. В него вводится текст. Сделайте так, чтобы после захода на
  эту страницу через некоторое время, введенный текст остался в textArea. Текст 
  должен запоминаться в локальном хранилище.*/
 
let txtArea = document.getElementById("local");
	const txtlocalStorage = localStorage.getItem("txtArea");
if (txtlocalStorage){
	txtArea.value = txtlocalStorage;
};
	txtArea.oninput = () => {
localStorage.setItem("txtArea",txtArea.value);
};
	let area = localStorage.setItem("text", txtArea);

  /* 5. Реализуйте записную книгу, хранящую данные в локальном хранилище.*/
 
$('#add').click( function() {
  var Description = $('#description').val();
if($("#description").val() == '') {
  $('#alert').html("Введите запись в текстовое поле.");
$('#alert').fadeIn().delay(2000).fadeOut();
  return false;
  }
$('#smile').prepend("<li><input id='check' name='check' type='checkbox'/>"
  + Description + "</li>");
$('#form')[0].reset();
  var smile = $('#smile').html();
localStorage.setItem('smile', smile);
  return false;
  });
  
  if(localStorage.getItem('smile')) {
  $('#smile').html(localStorage.getItem('smile'));
  }
  
  $('#clear').click( function() {
  window.localStorage.clear();
  location.reload();
  return false;
  });
 
  /* 6 . Реализуйте инпут, в который вводится число и по мере ввода оно автоматически 
  разбивается на тройки чисел. Что то типа когда вы вводите телефон где то на сайте 
  и он потом форматируеться в этом инпуте. */
  
  const input = document.querySelector('input');
  input.addEventListener('input', updateValue)
  
    function updateValue(a) {
	let text = a.target.value
	console.log('text: ' + text)
	let textWithoutSymbols = text
	.replaceAll('-', '')
	console.log('textWithoutSymbols: ' + textWithoutSymbols)
	
	let charArr = textWithoutSymbols.split('')
	let charArrTarget = []
  
	charArr.forEach((char, index) => {
  		if (index%3 === 2 && charArr.length !== index + 1) {
		  charArrTarget.push(char)
		charArrTarget.push('-')
	  } else {
	  charArrTarget.push(char)
	  }
   	})
	
	res = charArrTarget.join('')
  	  a.target.value = res
	}